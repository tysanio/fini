﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'pt', {
	fontSize: {
		label: 'Tamanho',
		voiceLabel: 'Tamanho da letra',
		panelTitle: 'Tamanho da letra'
	},
	label: 'Fonte',
	panelTitle: 'Nome do Tipo de Letra',
	voiceLabel: 'Tipo de Letra'
} );
