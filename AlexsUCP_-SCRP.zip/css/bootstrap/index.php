<?php

Header("location:../../dashboard.php");
?>