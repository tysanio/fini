# Desert County Roleplay

This is the official Desert County Roleplay gamemode. This gamemode is being provided as-is. We ask that you do not use the Desert County Roleplay name, logo or attribute your own server as a direct continuation of DC-RP.

## Giving yourself admin
You need to create yourself an in-game account first by registering in-game.
Then you need to log yourself out and log into the MySQL database.

Then execute the following query:
``UPDATE players SET AdminLevel = 5 WHERE username = 'USERNAME'``
Replace USERNAME with your account name, or
``UPDATE players SET AdminLevel = 5 WHERE id = ID``
Replace ID with your account ID (integer/number).

## License:
MIT License

## Installation:
You must change mysql.cfg to match your local mysql settings.  
Make sure you also have custom assets installed otherwise you will not see the login/register dialog. 