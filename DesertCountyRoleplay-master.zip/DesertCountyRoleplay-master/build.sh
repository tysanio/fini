echo "Copyright (C) 2018 Desert County Roleplay"
echo "Exectuting SA-MP gamemode build..."
sampctl package ensure
sampctl package build